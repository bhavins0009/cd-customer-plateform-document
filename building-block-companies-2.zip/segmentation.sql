ALTER TABLE `cd-customer-platform`.`segmentation`   
  ADD COLUMN `distribution_partner_id` INT(11) NULL AFTER `description`;
